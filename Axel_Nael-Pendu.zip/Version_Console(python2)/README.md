# Pendu
Le jeux du pendu (en version console pour l'instant) (le programme est codé en Python 2.)

Pour ajouter un mot, il suffit de l'ajouter à la suite des autres mots dans le fichier ListemotPendu, séparé par une virgule (mais pas d'espace.)


Pour supprimer les scores, il suffit de supprimer l'ensemble du document ScorePendu.txt (penser à bien vérifier qu'un retour à la ligne n'ai pas été entré)


fctPendu.py contient la fonction principale du pendu.


trilistemot est la fonction qui permet de sortir une liste de mot trié par taille puis par ordre alphabétique du fichier ListemotPendu.txt.

Have Fun!
