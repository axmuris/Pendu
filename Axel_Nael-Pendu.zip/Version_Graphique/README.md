# Pendu
Voici la version graphique de mon pendu.

Cette version est en python 3, contrairement à la version console qui elle est en python 2.

La première version ayant été faite en python 2 (les pc de la bibliothèque n'ont pas été mis à jour) et souhaitant refaire la version graphique
car la première version ne marchais pas du tout, j'ai décidé de refaire entièrement le programme de cette version.

Seul la fonciton qui récupère un mot d'un fichier texte a été conservée.

Have Fun!
