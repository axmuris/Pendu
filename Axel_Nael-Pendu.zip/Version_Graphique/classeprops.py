# -*- coding: utf-8 -*-
"""
Created on Sun Dec 20 11:45:58 2020

@author: axeln
"""


class propos:
    def __init__(self):
        self.listepro=[]
        
    def ajout(self,lettre):
        self.listepro.append(lettre)
